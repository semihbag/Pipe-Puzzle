
public enum Cell_Direction {
	NORTH,
	EAST,
	SOUTH,
	WEST
}