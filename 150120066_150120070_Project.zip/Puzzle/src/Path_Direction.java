
public enum Path_Direction {
	UP,
	RIGHT,
	DOWN,
	LEFT
}